from django.shortcuts import render,redirect
from myapp.models import Employee

from myapp.forms import EmployeeForm
from django.contrib import messages


# Create your views here.

def index (request) :
    return render (request,'index.html')


# def list_employee(request):
#     return render(request,'list_employee.html')


def list_employee(request):
    allemp = Employee.objects.order_by('-id')
    context = {'employees':allemp}
    return render(request,'list_employee.html',context)

def view_employee(request,id):
    emp = Employee.objects.get(pk=id)
    context = {'employee':emp,'title': 'Employee Details'}
    return render(request,'view_emp.html',context)

def create_employee(request):
    
    if request.method == "POST":
        form = EmployeeForm(request.POST)
        
        if form.is_valid():
            form.save()
            messages.success(request,"Data Inserted Successfully....")
         
            return redirect('employee_list')
    else:
        form = EmployeeForm()
          
    context = {'title': 'New Employee','form': form}
    return render(request,'create_employee.html',context)

def edit_employee(request,id):
    if request.method =="POST":
        employee = Employee.objects.all().order_by('id')
        form = EmployeeForm(request.POST or None, request.FILES,instance=employee)
        if form.is_valid():
            form.save()
        messages.success(request,"Data Updated Successfully...")
        return redirect('employee_list')
    
    else:
        employee = Employee.objects.get(pk=id)
        form = EmployeeForm(request.POST or None, instance=employee)
    
    context = {'title':'Edit','form': form,'employee' : employee}
    return render (request, "EditForm.html",context)

def destroy(request,id):
    employee = Employee.objects.get(pk=id)
    employee.delete()
    messages.success(request,("Data Deleted Successfully"))
    return redirect("employee_list")

# def user_register(request):
#     if request.method =="POST":
#         form = SignuUpForm(request.POST)
#         if form.is_valid():
    
    
        









