from django.urls import path
from myapp import views

urlpatterns = [
    path('list/',views.list_employee,name='employee_list'),
    path('details/<int:id>/',views.view_employee,name='employee_view'),
    path('create/',views.create_employee,name='employee_create'),
    path('edit/<int:id>/',views.edit_employee,name='employee_edit'),
    path('delete/<int:id>/',views.destroy,name='employee_delete'),
    
   
   
]
