from django.contrib import admin
from myapp.models import Department,Employee

# Register your models here.
class EmployeeAdmin(admin.ModelAdmin):
    search_fields = ['email','name']
    
    list_display = ['name','email','phone','doj','salary']
    list_per_page = 6
    
    class Meta:
        model = Employee
        


admin.site.register(Department)
admin.site.register(Employee,EmployeeAdmin)


    